﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Com.Cognizant.Truyum.Model
{
   public  class Cart
    {
        private List<MenuItem> _menuItemList;
        private double _total;


        public Cart()
        {

        }

        public Cart(List<MenuItem> _menuItemList, double _total)
        {
            this.MenuItemList = _menuItemList;
            this.Total = _total;
        }

        public List<MenuItem> MenuItemList
        {
            get
            {
                return _menuItemList;
            }

            set
            {
                _menuItemList = value;
            }
        }

        public double Total
        {
            get
            {
                return _total;
            }

            set
            {
                _total = value;
            }
        }


        /*public override string ToString()
        {
            string menuItemInfo = string.Empty;
            foreach(MenuItem menuItem in this._menuItemList)
            {
                menuItemInfo = menuItemInfo + menuItem.Name + "   " + menuItem.FreeDelivery + "   " + menuItem.Price;
  
            }
            return string.Format("{0}\n{1}", menuItemInfo, this._total);
            
        }*/

        
    }
    }

