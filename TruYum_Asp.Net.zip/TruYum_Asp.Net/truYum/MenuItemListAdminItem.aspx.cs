﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
//refer to the DAO
using Com.Cognizant.Truyum.Dao;
//Create a dataset to hold record collected from DAO Method
using System.Data;
using System.Globalization;
using System.Threading;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        if(!IsPostBack)
        {
            DisplayItemsAdmin();
        }
    }

    protected void gridItem_EditRow(object sender, GridViewEditEventArgs e)
    {
        //Create a row in grid for seraching the edition
    
        GridViewRow row = gridItem.Rows[e.NewEditIndex];
       
        string itemId = row.Cells[0].Text;
        /* string name = row.Cells[1].Text;
         string price = row.Cells[2].Text;
         string dateoflaunch = row.Cells[4].Text;*/
        Response.Redirect("EditMenuItem.aspx?ItemId= " + itemId);
        //Response.Redirect("EditMenuItem.aspx?ItemId= "+itemId+"&Name= "+name+"&Price= "+price+"&Date Of Launch= "+dateoflaunch);
    }

    protected void gridItem_CancelEdit(object sender, GridViewCancelEditEventArgs e)
    {
        gridItem.EditIndex = -1;

    }
    protected void DisplayItemsAdmin()
    {
        MenuItemDaoCollection menuCollection = new MenuItemDaoCollection();
        List<Com.Cognizant.Truyum.Model.MenuItem> menuList = menuCollection.GetMenuItemListAdmin();
        gridItem.DataSource = menuList;
        gridItem.DataBind();
    }
    protected override void InitializeCulture()
    {
        CultureInfo ci = new CultureInfo("en-IN");
        ci.NumberFormat.CurrencySymbol = "₹";
        Thread.CurrentThread.CurrentCulture = ci;

        base.InitializeCulture();
    }

    protected void gridItem_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}